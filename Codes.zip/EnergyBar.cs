using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnergyBar : MonoBehaviour
{
    [SerializeField]
    private Image _energybarSprite;
     [SerializeField]
     //private float _reduceSpeed=2;
    //private float _target=1;
    
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void UpdateEnergyBar(float maxEnergy, float currentEnergy){
        _energybarSprite.fillAmount= currentEnergy/maxEnergy;
    }
    
    
    // Update is called once per frame
    void Update()
    {
       // _energybarSprite.fillAmount= Mathf.MoveTowards(_energybarSprite.fillAmount, _target, _reduceSpeed*Time.deltaTime);
    }
}
