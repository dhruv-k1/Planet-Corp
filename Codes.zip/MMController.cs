using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MMController : MonoBehaviour
{
   
    public void PlayGame(){
        Debug.Log("Button Pressed");
        SceneManager.LoadScene("Gameplay");
    }


    void Start()
    {
        
    }

    
    void Update()
    {
        
    }
}
