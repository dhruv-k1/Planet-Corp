using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CalorieBar : MonoBehaviour
{
   public Slider caloriebar;

   private float maxCal = 100;
   private float currentCal;
   
   public static CalorieBar instance;
    
    private void Awake(){
        instance = this;
        
    }
    
    // Start is called before the first frame update
    void Start()
    {
        
        caloriebar.maxValue = maxCal;
        caloriebar.value= maxCal;

    }

    //public void UseCal(int amount){
    //    if(currentCal - amount >=0){
    //        currentCal -= amount;
    //        caloriebar.value = currentCal;
    //        StartCoroutine(RegainCal());
    //    }
//
    //    else {
    //        Destroy(gameObject);
    //    }
    //}
    //
    //private IEnumerator RegainCal(){
    //    yield return new WaitForSeconds(2);
//
    //    while(currentCal<maxCal){
    //        currentCal += -maxCal/10;
    //        caloriebar.value = currentCal;
    //    }
    //}
    
    
    
    
    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Space)){
            decCal();
        }
    }

    private void decCal(){
        if(currentCal!=0){
            currentCal -= 10*Time.deltaTime;
        }
    }







}
