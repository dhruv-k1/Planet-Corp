using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FoodSpawner : MonoBehaviour
{
    [SerializeField]
    private GameObject[] foodReference;

    private GameObject spawnedFood;

    [SerializeField]
    private Transform leftPosition, rightPosition;
    
    private int randomIndex;
    private int randomSide;
    
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(SpawnFood());
    }


    IEnumerator SpawnFood(){
       
       while(true){
       
        yield return new WaitForSeconds(Random.Range(1,5));
        randomIndex = Random.Range(0, foodReference.Length);
        randomSide = Random.Range(0,2);
    
        spawnedFood = Instantiate(foodReference[randomIndex]);

        if(randomSide==0){
            spawnedFood.transform.position = leftPosition.position;
           spawnedFood.GetComponent<Enemy>().speed = Random.Range(4, 10);
        }

        else if(randomSide!=0){
           spawnedFood.transform.position = rightPosition.position;
           spawnedFood.GetComponent<Enemy>().speed = -Random.Range(4, 10); 
            spawnedFood.transform.localScale = new Vector3(-0.706514f,0.6176544f,1f);
        }
    }
   }
}
